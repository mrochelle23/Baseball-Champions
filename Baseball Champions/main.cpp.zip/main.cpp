//
//  main.cpp
//  Baseball Champions
//
//  Created by Mikhai Rochelle on 6/9/24.
//
#include <iostream>
#include <fstream>
#include <string>
#include <vector>

using namespace std;

const string TEAMS_FILE = "Teams.txt";
const string WORLD_SERIES_WINNERS_FILE = "WorldSeriesWinners.txt";

// Function to read file into a vector of strings
vector<string> readFile(const string& filename) {
    vector<string> lines;
    ifstream file(filename);
    if (file.is_open()) {
        string line;
        while (getline(file, line)) {
            lines.push_back(line);
        }
        file.close();
    } else {
        cerr << "Unable to open file: " << filename << endl;
    }
    return lines;
}

// Function to count occurrences of a team in the winners list
int countWins(const vector<string>& winners, const string& teamName) {
    int count = 0;
    for (const string& winner : winners) {
        if (winner == teamName) {
            count++;
        }
    }
    return count;
}

int main() {
    // Read teams from Teams.txt
    vector<string> teams = readFile(TEAMS_FILE);
    if (teams.empty()) {
        cerr << "Teams.txt is empty or cannot be read." << endl;
        return 1;
    }

    // Read World Series winners from WorldSeriesWinners.txt
    vector<string> worldSeriesWinners = readFile(WORLD_SERIES_WINNERS_FILE);
    if (worldSeriesWinners.empty()) {
        cerr << "WorldSeriesWinners.txt is empty or cannot be read." << endl;
        return 1;
    }

    // Display teams from Teams.txt
    cout << "List of MLB Teams:" << endl;
    for (const string& team : teams) {
        cout << team << endl;
    }
    cout << endl;

    // Prompt user to enter a team name
    string userTeam;
    cout << "Enter the name of a team to check their World Series wins: ";
    getline(cin, userTeam);

    // Count the number of World Series wins for the user-entered team
    int wins = countWins(worldSeriesWinners, userTeam);

    // Display results
    if (wins > 0) {
        cout << userTeam << " has won the World Series " << wins << " time(s) from 1950 to 2014." << endl;
    } else {
        cout << userTeam << " did not win the World Series from 1950 to 2014." << endl;
    }

    return 0;
}
